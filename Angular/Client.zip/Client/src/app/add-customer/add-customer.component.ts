import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer.model';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  cust : Customer = new Customer();
  constructor(private router: Router, private service : CustomerService) {
}


  ngOnInit() {
  }


  addCustomer():void{
    this.service.createCustomer(this.cust).subscribe( data =>{
      alert("User created SuccessFully.");
    });
  }
}
