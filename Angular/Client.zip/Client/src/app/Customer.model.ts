export class Customer {

    id: Number;
   name: String;
   balance : Number;
  }