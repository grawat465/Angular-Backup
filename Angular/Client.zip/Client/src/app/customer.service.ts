import { Injectable } from '@angular/core';
import {HttpHeaders,HttpClient} from '@angular/common/http';
import {Customer} from './Customer.model';





@Injectable({
  providedIn: 'root'
})
export class CustomerService {


  constructor(private http : HttpClient) { }


private userUrl = 'http://localhost:9000/customer';
//private userUrl = '/customer';

public getCustomer() {
  return this.http.get(this.userUrl+"s");
}

public getCustomerId(customer) {
  return this.http.get(this.userUrl+"/"+customer.id);
}


public deleteCustomer(customer) {
  return this.http.delete(this.userUrl + "/"+ customer.id);
}

public createCustomer(customer) {
  return this.http.post(this.userUrl, customer);
}

}
